%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-10-10T23:45:57+09:00*%
%TF.ProjectId,YM60JIS_Plate,594d3630-4a49-4535-9f50-6c6174652e6b,v1.1*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-10-10 23:45:57*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,4.500000*%
G04 APERTURE END LIST*
D10*
%TO.C,REF\u002A\u002A*%
X25500000Y-28500000D03*
%TD*%
%TO.C,*%
X260350000Y-28500000D03*
%TD*%
M02*
